This is an sqlreplace plugin.

This plugin replaces a set of variables before a statement is executed.
There is only one regexPattern transformed from $ to \$
If there is a need to specify variables containing more regexPattern than one can specify this in the perferences
Like this ^Var = bla  to \^Var = bla (But i never tested this)
 