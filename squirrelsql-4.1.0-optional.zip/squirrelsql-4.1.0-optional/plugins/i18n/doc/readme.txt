This is an plugin is meant help to i18n SQuirreL.
