This plugin allows Sybase ASE users to script Procedures and Views 
using the right click popup menu.  It was created using the example
plugin.