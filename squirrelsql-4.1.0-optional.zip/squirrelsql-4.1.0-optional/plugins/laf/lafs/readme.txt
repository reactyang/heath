This directory contains the standard Look and Feels
supplied with the Look and Feel plugin.
